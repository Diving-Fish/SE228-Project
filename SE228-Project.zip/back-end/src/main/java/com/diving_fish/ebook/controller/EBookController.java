package com.diving_fish.ebook.controller;

import org.springframework.boot.autoconfigure.*;
import org.springframework.core.io.ClassPathResource;
import org.springframework.web.bind.annotation.*;
import net.sf.json.JSONArray;

import java.io.*;

@RestController
@EnableAutoConfiguration
public class EBookController {

    @RequestMapping(value = "/booklist", method = RequestMethod.GET)
    @ResponseBody
    public JSONArray booklist() throws IOException {
        ClassPathResource bl = new ClassPathResource("static/booklist.json");
        File blf = bl.getFile();
        BufferedReader br = new BufferedReader(new FileReader(blf));
        String jsons = "";
        String line;
        while ((line = br.readLine()) != null) {
            jsons += line;
        }
        return JSONArray.fromObject(jsons);
    }
}